/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdg <sdg@student.42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/26 14:23:39 by mdias-ma          #+#    #+#             */
/*   Updated: 2023/07/22 01:21:38 by sdg              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# include "libft.h"
# include "events.h"
# include "hash_table.h"
# include "builtins.h"
# include "scanner.h"
# include "parser.h"
# include "helpers.h"
# include "exec.h"
# include "expansion.h"

#endif
