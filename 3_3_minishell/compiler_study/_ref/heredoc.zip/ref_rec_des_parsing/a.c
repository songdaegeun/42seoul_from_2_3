#include <stdio.h>

int main(void) {
	printf("hi\n");
	return(42);
}

